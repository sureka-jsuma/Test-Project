import { useState } from "react";
import SegmentHeader from "../segmentheader";
import SegmentDetails from "../segmentdetails";
import { VIEW_AUD, SAVE_SEG } from "../../constants";
import RUButton from "../button/RUButton";
import "./style.scss";

function CreateSegment() {
  const [segdrawer, setSegdrawer] = useState(false);

  const openSegment = () => {
    setSegdrawer(true);
  };
  const closeSegment = () => {
    setSegdrawer(false);
  };

  return (
    <>
      <SegmentHeader title={VIEW_AUD} />
      <div className="create-segment">
        <RUButton
          handleClick={openSegment}
          label={SAVE_SEG}
          className="save-segment"
        />
      </div>
      {segdrawer && <SegmentDetails closeSegment={closeSegment} />}
    </>
  );
}

export default CreateSegment;
