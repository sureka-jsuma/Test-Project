const AppConfig = window.APP_CONFIG;

if (!AppConfig) {
  console.error("[Index] *** Error loading Config File ***");
}

export const AppSettings = {
  API_URL: AppConfig.API_URL,
};
