import { useState, useEffect } from "react";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import "./style.scss";

export default function RUControls({
  label,
  options,
  handleFieldChange,
  className = "",
  placeholder = "",
  type,
  rows,
  readOnly = false,
  value = false,
  disabled = false,
}) {
  const [fieldValue, setFieldValue] = useState(value);
  const isSelect = type === "select";
  const isValueActivate = isSelect || value !== false;
  const handleChange = (event) => {
    const fieldVal = event ? event.target.value : "";
    isValueActivate && setFieldValue(fieldVal);
    handleFieldChange && handleFieldChange(fieldVal, event);
  };

  useEffect(() => {
    setFieldValue(value);
  }, [value]);

  const InputLabelProps = { shrink: true };
  const InputProps = { readOnly };
  const textFieldProps = {
    select: isSelect,
    disabled: disabled,
    label,
    type,
    placeholder,
    onChange: handleChange,
    className: `ru-field ${className}`,
    InputLabelProps,
    rows,
    InputProps,
  };
  if (isValueActivate) textFieldProps.value = fieldValue;

  return (
    <TextField {...textFieldProps}>
      {options &&
        options.map(({ name, value, isdisabled = false }) => (
          <MenuItem key={value} value={value} disabled={isdisabled}>
            {name}
          </MenuItem>
        ))}
    </TextField>
  );
}
