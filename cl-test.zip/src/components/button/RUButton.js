import "./style.scss";

export default function RUButton({
  label = "",
  className = "",
  disabled = false,
  handleClick,
}) {
  return (
    <button
      className={`ru-button ${className}`}
      disabled={disabled}
      onClick={handleClick}
    >
      {label}
    </button>
  );
}
