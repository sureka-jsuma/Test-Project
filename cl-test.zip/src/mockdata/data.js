import {
  F_NAME,
  L_NAME,
  GENDER,
  AGE,
  ACC_NAME,
  CITY,
  STATE,
} from "../constants";

export const fieldArray = [
  { name: F_NAME, value: "first_name", selected: false, uTraits: true },
  { name: L_NAME, value: "last_name", selected: false, uTraits: true },
  { name: GENDER, value: "gender", selected: false, uTraits: true },
  { name: AGE, value: "age", selected: false, uTraits: true },
  { name: ACC_NAME, value: "account_name", selected: false, uTraits: false },
  { name: CITY, value: "city", selected: false, uTraits: false },
  { name: STATE, value: "state", selected: false, uTraits: false },
];
