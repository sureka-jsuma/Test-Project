import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import "./style.scss";

function SegmentHeader({ title, handleClose }) {
  return (
    <div className="segment-header">
      <span className="segment-title">
        <ArrowBackIosIcon onClick={handleClose} className="go-back" />
        {title}
      </span>
    </div>
  );
}

export default SegmentHeader;
