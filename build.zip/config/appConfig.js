var APP_CONFIG = window.APP_CONFIG || {};
APP_CONFIG.API_URL =
  "https://webhook.site/6ff9f96c-fc77-4018-9541-96cc3561cf8f";
