export const VIEW_AUD = "View Audience";
export const SAVE_SEG = "Save Segment";
export const SAVING_SEG = "Saving Segment";

export const EN_OF_SEG = "Enter the Name of the Segment";
export const N_OF_SEG = "Name of the segment";
export const SAVE_SEG_BUTTON = "Save the Segment";
export const SEG_SCHEMA_INFO =
  "To save your segment, you need to add the schemas to build the query";

export const USER_TRAITS = "User Traits";
export const GROUP_TRAITS = "Group Traits";
export const ADD_SCHEMA = "Add schema to segment";

export const F_NAME = "First Name";
export const L_NAME = "Last Name";
export const GENDER = "Gender";
export const AGE = "Age";
export const ACC_NAME = "Account Name";
export const CITY = "City";
export const STATE = "State";

export const CANCEL = "Cancel";
