import { useEffect, useState } from "react";
import axios from "axios";
import SegmentHeader from "../segmentheader";
import Drawer from "@mui/material/Drawer";
import CircleIcon from "@mui/icons-material/Circle";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import {
  SAVING_SEG,
  EN_OF_SEG,
  N_OF_SEG,
  SAVE_SEG_BUTTON,
  SEG_SCHEMA_INFO,
  CANCEL,
  USER_TRAITS,
  GROUP_TRAITS,
  ADD_SCHEMA,
} from "../../constants";
import { AppSettings } from "../../utils/appSettings";
import RUButton from "../button/RUButton";
import RUControls from "../field";
import { fieldArray } from "../../mockdata/data";
import "./style.scss";

function SegmentDetails({ closeSegment }) {
  const [segmentName, setSegmentName] = useState("");
  const [selectedFields, setSelectedFields] = useState([]);
  const [schema, setSchema] = useState(fieldArray);
  const [addtoschema, setAddtoschema] = useState("all");

  const getOption = (combo = "") => {
    let arr = schema.filter((obj) => obj.selected === false);
    return combo === ""
      ? [
          { name: "Add schema to segment", value: "all", isdisabled: true },
          ...arr,
        ]
      : [...schema.filter((obj) => obj.value === combo), ...arr];
  };

  const handleAddtoSchema = () => {
    if (addtoschema !== "all") {
      setSelectedFields([...selectedFields, addtoschema]);
      setAddtoschema("all");
    }
  };

  const handleRemove = (index) => {
    setSelectedFields((current) => {
      let arr = JSON.parse(JSON.stringify(current));
      arr.splice(index, 1);
      return arr;
    });
  };

  const saveSegmentInfo = () => {
    let selectedarr = [];
    schema.forEach((obj) => {
      if (obj.selected === true) {
        selectedarr.push({ [obj.value]: obj.name });
      }
    });
    if (segmentName === "") window.alert("Please enter Segment Name");
    else {
      window.alert("Sending Data...");
      axios
        .post(AppSettings.API_URL, {
          segment_name: segmentName,
          schema: selectedarr,
        })
        .then((resp) => {
          setSelectedFields([]);
          setSegmentName("");
          window.alert("Saved successfully.");
        })
        .catch((error) => {
          window.alert("Network Error!");
        });
    }
  };

  useEffect(() => {
    setSchema((current) => {
      let arr = [];
      arr = JSON.parse(JSON.stringify(current));
      arr.forEach((o, i) => {
        if (selectedFields.includes(o.value)) {
          arr[i].selected = true;
        } else arr[i].selected = false;
      });
      return arr;
    });
  }, [selectedFields]);

  return (
    <>
      <Drawer anchor="right" open={true} className="segment-drawer">
        <SegmentHeader title={SAVING_SEG} handleClose={closeSegment} />
        <div className="segment-details-body">
          <div className="segment-name">{EN_OF_SEG}</div>
          <div>
            <RUControls
              type="text"
              placeholder={N_OF_SEG}
              value={segmentName}
              handleFieldChange={(fieldVal) => {
                setSegmentName(fieldVal);
              }}
              className="seg-name-width"
            />
          </div>
          <div className="seg-schema-info">{SEG_SCHEMA_INFO}</div>
          <div className="seg-traits">
            <span className="traits">
              <CircleIcon fontSize="8" color="success" />
              {" - "}
              {USER_TRAITS}
            </span>
            <span className="traits">
              <CircleIcon fontSize="8" color="error" />
              {" - "}
              {GROUP_TRAITS}
            </span>
          </div>
        </div>
        <div className="segment-schema-selection">
          {selectedFields.length > 0 && (
            <div className="blue-box">
              {selectedFields.map((field, index) => (
                <div className="schema-controls">
                  <CircleIcon
                    sx={{
                      fontSize: "10px",
                      fontWeight: "medium",
                      marginRight: "10px",
                    }}
                    color={`${
                      ["account_name", "city", "state"].includes(field)
                        ? "error"
                        : "success"
                    }`}
                  />
                  <RUControls
                    type="select"
                    options={getOption(field)}
                    value={field}
                    handleFieldChange={(fieldVal) => {
                      setSelectedFields((current) => {
                        let arr = JSON.parse(JSON.stringify(current));
                        arr.splice(index, 1, fieldVal);
                        return arr;
                      });
                    }}
                    className="set-width"
                  />
                  <RUButton
                    handleClick={() => handleRemove(index)}
                    label={<RemoveIcon />}
                    className="remove-control"
                  />
                </div>
              ))}
            </div>
          )}
          <span className="add-schema-combo">
            <CircleIcon
              sx={{
                fontSize: "10px",
                fontWeight: "medium",
                marginRight: "10px",
              }}
              color="disabled"
            />
            <RUControls
              type="select"
              options={getOption()}
              value={addtoschema}
              handleFieldChange={(fieldVal) => {
                setAddtoschema(fieldVal);
              }}
              className="set-width"
            />
          </span>
          <div className="add-to-schema" onClick={handleAddtoSchema}>
            <AddIcon
              sx={{
                fontSize: 10,
                fontWeight: "medium",
              }}
            />
            {ADD_SCHEMA}
          </div>
        </div>

        <div className="segment-details-footer">
          <RUButton
            handleClick={saveSegmentInfo}
            label={SAVE_SEG_BUTTON}
            className="save-segment-info"
          />
          <RUButton
            handleClick={closeSegment}
            label={CANCEL}
            className="cancel-segment"
          />
        </div>
      </Drawer>
    </>
  );
}

export default SegmentDetails;
