import CreateSegment from "./components/createsegment";
import "./App.scss";

function App() {
  return (
    <div className="app">
      <CreateSegment />
    </div>
  );
}

export default App;
